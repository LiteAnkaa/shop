
const express = require("express");
const multer = require("multer");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = path.join(__dirname, "data");
const DATA = path.join(DATA_DIR, "configs.json");
const UPLOADS = path.join(__dirname, "public", "uploads");
fs.mkdirSync(DATA_DIR, { recursive: true });
fs.mkdirSync(UPLOADS, { recursive: true });
if (!fs.existsSync(DATA)) fs.writeFileSync(DATA, "[]", "utf8");

const storage = multer.diskStorage({
  destination: (_, __, cb) => cb(null, UPLOADS),
  filename: (_, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, crypto.randomUUID() + ext);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024, files: 2 },
  fileFilter: (_, file, cb) => {
    const image = ["image/png", "image/jpeg", "image/webp"].includes(file.mimetype);
    const config = /\.(json|txt|cfg)$/i.test(file.originalname);
    if (image || config) cb(null, true);
    else cb(new Error("Разрешены аватарки PNG/JPG/WEBP и конфиги JSON/TXT/CFG"));
  }
});

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

function readConfigs() {
  try { return JSON.parse(fs.readFileSync(DATA, "utf8")); }
  catch { return []; }
}
function writeConfigs(items) {
  fs.writeFileSync(DATA, JSON.stringify(items, null, 2), "utf8");
}

app.get("/api/health", (_, res) => res.json({ ok: true }));
app.get("/api/configs", (_, res) => {
  res.json(readConfigs().sort((a, b) => b.createdAt - a.createdAt));
});

app.post("/api/configs", upload.fields([
  { name: "avatar", maxCount: 1 },
  { name: "configFile", maxCount: 1 }
]), (req, res) => {
  const name = String(req.body.name || "").trim().slice(0, 60);
  const description = String(req.body.description || "").trim().slice(0, 500);
  const author = String(req.body.author || "Аноним").trim().slice(0, 40);

  if (!name) return res.status(400).json({ error: "Введите название конфига" });

  const avatarFile = req.files?.avatar?.[0];
  const configFile = req.files?.configFile?.[0];

  const item = {
    id: crypto.randomUUID(),
    name,
    description,
    author,
    avatar: avatarFile ? "/uploads/" + avatarFile.filename : null,
    configUrl: configFile ? "/uploads/" + configFile.filename : null,
    configOriginalName: configFile ? configFile.originalname : null,
    createdAt: Date.now()
  };

  const all = readConfigs();
  all.push(item);
  writeConfigs(all);
  res.status(201).json(item);
});

app.use((err, req, res, next) => {
  console.error(err);
  const message = err?.message || "Ошибка сервера";
  res.status(400).json({ error: message });
});

app.listen(PORT, () => {
  console.log(`Bunny Visual Community запущен: http://localhost:${PORT}`);
});
